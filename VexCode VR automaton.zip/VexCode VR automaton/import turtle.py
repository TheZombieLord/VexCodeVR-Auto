import turtle
import os

log_messages = [
    '#Made by me becasue i wanted to automate vex code vr bc it sucked',
    "#find the code at my repository: https://github.com/TheZombieLord/VexCodeVR-Auto/ [yes im plugging my github lol] ",
    "#Press up/down arrow to change turn rate",
    "#Press Z/X to change movement rate",
    "vr_thread(when_started1)"
]

for msg in log_messages:
    print(msg)

screen = turtle.Screen()
root = screen._root
root.attributes('-alpha', 0.5)

t = turtle.Turtle()

turn_increment = 5
forward_increment = 10
pen_down = True

def log_message(msg):
    print(msg)
    log_messages.append(msg)

def move_forward():
    t.forward(forward_increment)
    log_message(f"drivetrain.drive_for(FORWARD, {forward_increment}, MM)")

def rotate_right():
    t.right(turn_increment)
    log_message(f"drivetrain.turn_for(RIGHT, {turn_increment}, DEGREES)")

def rotate_left():
    t.left(turn_increment)
    log_message(f"drivetrain.turn_for(LEFT, {turn_increment}, DEGREES)")

def increase_turn():
    global turn_increment
    turn_increment += 5

def decrease_turn():
    global turn_increment
    turn_increment -= 5

def increase_forward():
    global forward_increment
    forward_increment += 5

def decrease_forward():
    global forward_increment
    forward_increment -= 5

def toggle_pen():
    global pen_down
    if pen_down:
        t.penup()
        log_message("Pen up")
    else:
        t.pendown()
        log_message("Pen down")
    pen_down = not pen_down

def save_logs():
    if not os.path.exists("Output"):
        os.makedirs("Output")
    with open("Output/output.txt", "w", encoding="utf-8") as f:
        for message in log_messages:
            f.write(message + "\n")
    log_message("Logs saved to Output/output.txt")
    screen.bye()

screen.listen()
screen.onkeypress(move_forward, "w")
screen.onkeypress(rotate_right, "d")
screen.onkeypress(rotate_left, "a")
screen.onkeypress(increase_turn, "Up")
screen.onkeypress(decrease_turn, "Down")
screen.onkeypress(increase_forward, "z")
screen.onkeypress(decrease_forward, "x")
screen.onkeypress(toggle_pen, "space")
screen.onkeypress(save_logs, "Return")

turtle.mainloop()
